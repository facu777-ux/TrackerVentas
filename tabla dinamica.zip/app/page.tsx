"use client"

import DemoPage from "../demo-page"

export default function SyntheticV0PageForDeployment() {
  return <DemoPage />
}